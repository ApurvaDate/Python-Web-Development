from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from flask import render_template

class SignUpForm(FlaskForm):
    username = StringField('Username')
    password= PasswordField("Password")
    submit = SubmitField('Sign up')

#this is a easy way to create a sign up form in flask
#now we have to create a html for this, how to render this form in our own site? 