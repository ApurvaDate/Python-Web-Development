#import Flask from flask module
from flask import Flask, render_template, request, url_for
from forms import SignUpForm

#initialize the application
app = Flask(__name__) #this is a general convention to initialize flask app , this line is creating the application

#create a secret key for the flask app
app.config['SECRET_KEY'] = 'something_secret'

@app.route('/')  #here we are creating a route on our server that is /, once we create a route we define a function
def home():
    return "Hello World"
#here we are routing some function, and the function we are routing to is home function and the home function is returning hello world


########## routing and Variable rules
#how to access different URLs and web pages
@app.route('/about')
def about():
    return "The aboue page"


# @app.route("/blog")
# def blog():
#     return "this is the blog"

#here we are defining the actual route the server should go to and what it should return.

#variable rules

@app.route("/blog/<blog_id>") 
def blogpost(blog_id):
    return "this is the blogpost number " + str(blog_id) 
#here we are sepcifying a rule inside the route
#when one tries to access anything /blog/something refer to that something as a variable = blog_id 
#like this we specify dfferent variable rules
#we can also write it as 

# @app.route("/blog/string:blog_id")
# def blogpost(blog_id):
#     return "This is the blogpost number " + blog_id  #here we do not need the string


###### temaplates in flask

#HTML used for websites
#blog with html

@app.route("/blog")
def blog():
    posts = [{"title" : "Technology in 2019 ", "author": "Avi"},
             {"title" : "Expansion of Oil in Russia", "author" : "Bob"} ]  #this are post titles
    return render_template('blog.html', author = "apurva", sunny = True, posts = posts)


@app.route("/signup", methods = ['GET', 'POST'])
def signup():
    form = SignUpForm()
    if form.is_submitted():
        result = request.form
        return render_template("user.html", result = result)
    return render_template ('signup.html', form = form)


if __name__ == "__main__":
    app.run()




























